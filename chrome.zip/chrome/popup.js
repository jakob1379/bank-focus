const checkbox = document.getElementById('toggle');

chrome.storage.local.get('hideEnabled', ({hideEnabled}) => {
  checkbox.checked = !!hideEnabled;
});

checkbox.addEventListener('change', async (e) => {
  const enabled = e.target.checked;
  await chrome.storage.local.set({ hideEnabled: enabled });

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { action: enabled ? 'enable' : 'disable' });
  }
});
